package edu.hawaii.chengh.action;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.GridLayout;

/**
 * User provides information to create an avatar.
 * 
 * @author Hansen Cheng
 *
 */
public class CreatePanel extends JPanel {
  
  private static final long serialVersionUID = 1L;

  private JLabel nameLabel = new JLabel("Name: "), ageLabel = new JLabel("Age: "),
                 calLabel = new JLabel("Calorie Limit: "), userName = new JLabel("Username: "), 
                 passCode = new JLabel("Password: ");
  
  private JTextField name = new JTextField(15), age = new JTextField(5),
                     calLimit = new JTextField(15), userId = new JTextField(15);
  
  private JPasswordField password = new JPasswordField(15);
                    
          
  /**
   * Construct panel and attributes.
   */
  public CreatePanel() {
    this.setLayout(new GridLayout(5, 0));
    this.add(nameLabel);
    this.add(name);
    this.add(ageLabel);
    this.add(age);
    this.add(calLabel);
    this.add(calLimit);
    this.add(userName);
    this.add(userId);
    this.add(passCode);
    this.add(password);
  }
  
  /**
   * Obtains information from the textfields that requires user to 
   * enter their information.
   * 
   * @return information from textfields.
   */
  public String fieldInfo() {
    return name.getText().trim() + "  " + age.getText().trim() + "  " + 
           calLimit.getText().trim() + "  " + userId.getText().trim();
  }
  
  /**
   * Converts password into a whole string.
   * 
   * @return a complete password.
   */
  public String secureCode() {
    char[] temp = password.getPassword();
    
    String code = "";
    
    for (int i = 0; i < temp.length; i++) {
      code += temp[i];
    }
    
    return code;
  }
  
  public void clearField() {
    name.setText("");
    age.setText("");
    calLimit.setText("");
    userId.setText("");
    password.setText("");
  }
}
